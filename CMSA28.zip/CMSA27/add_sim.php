<!DOCTYPE html>
<html lang="en">
    <body>
        <form action="submit_sim.php" method="post">
            <h2>Student Information Management</h2>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required> </br></br>
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required> </br></br>
            <label for="currentcourse">Current Course:</label>
            <input type="text" id="currentcourse" name="currentcourse" required> </br></br>
            <label for="previouscourse">Previous course:</label>
            <input type="text" id="previouscourse" name="previouscourse" required> </br></br>
            <label for="phoneno">Phone no:</label>
            <input type="text" id="phoneno" name="phoneno" required> </br></br>
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" required></br> </br>
            <label for="document">Document:</label>
            <input type="text" id="document" name="document" required></br> </br>
            

            
            <input type="submit" value="Register">

        </form>
</body>
</html>