<?php
// Include database connection
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $id = $_POST["id"];
    $faculty_name = $_POST["faculty_name"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $usertype = $_POST["usertype"];


    // Update the user's information in the database
    $sql = "UPDATE faculty SET faculty_name='$faculty_name', phone='$phone', email='$email', usertype='$usertype' WHERE id=$id";

    // Execute the update query
    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
        header("Location: view_staff.php");

    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>


