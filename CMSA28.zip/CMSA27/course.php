<html>
    <head>

    </head>
    <body>
        <form action ="submitAll.php" method="post">
            <h1> <p align = "center" >Course Management Module </p></h1>
            <h3> <p align = "left" >The courses provided in USBM </p></h3>
            
            
            
            <label for="Course"> course name:</label>
            <input type="text" id="course name" name="Course" required><br><br>
            <label for="Fees"> Fees:</label>
            <input type="text" id="Fees" name="Fees" required><br><br>
            <label for="Eligibility"> Eligibility:</label>
            <input type="text" id="Eligibility" name="Eligibility" required><br><br>
            <label for="Action"> Action:</label>
            <input type="text" id="Action" name="Action" required><br><br>
            <input type="submit" value="submit">

           
      </form>
            


    </body>
</html>